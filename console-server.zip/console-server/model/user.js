var mongoose = require('mongoose');

var Schema = mongoose.Schema;

/**
 * Get User model
 */
function getUserModel() {
	
	return new Schema({
		name: { type: String, index : true },   // username - need to be unique
		password: String, // password 
	});
}

module.exports = {
		getUserModel : getUserModel
};

