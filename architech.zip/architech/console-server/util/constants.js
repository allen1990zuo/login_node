//use to define some constants
const SERVER_RUN_MESSAGE="server is listening on :"
const USER_CAN_NOT_REGISTER="This User Name Was Already Registered! Please Try Another Username!";
const USER_REGISTER=" Successful Registered!"
module.exports = {
		SERVER_RUN_MESSAGE	  : SERVER_RUN_MESSAGE,
		USER_CAN_NOT_REGISTER : USER_CAN_NOT_REGISTER,	
		USER_REGISTER		  : USER_REGISTER
}