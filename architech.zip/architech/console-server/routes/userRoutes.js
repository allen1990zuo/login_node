
/***************************************************************
 * Routes for console server
 * 
 ****************************************************************/

var userImpl = require("../modelimpl/userImpl.js");
var constants = require('../util/constants.js');
module.exports = function(app) {
	
	app.post("/createUser",function(req,res){
		var user=req.body
		userImpl.create(user,function(err,results){
			if(err){
				var message=user.name+" "+err
				//can not register a new user
				res.send(message)
			}
			else{
				//successful register a new user
				var message=results.name+constants.USER_REGISTER
				res.send(message)
			}
		})
	})
    
    
};