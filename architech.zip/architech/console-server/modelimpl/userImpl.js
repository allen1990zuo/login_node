/***************************************************************
 * User Implementation
 *  
 ***************************************************************/

var dbUserAccess = require("../database/dbUserAccess.js");
var constants = require('../util/constants.js');
function create(user,callback){
	dbUserAccess.createUser(user,function(err,results){
		if(err){
			//can not register a new user
			callback(err,null)
		}
		else{
			//successful to register a new user
			callback(null,results)
		}
	})
}


module.exports={
		create:create
}