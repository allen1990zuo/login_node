


/***************************************************************
 * User Database Access: All user database calls are in here
 *  
 ***************************************************************/


var mongoose = require('mongoose');
var schema = require('../model/user').getUserModel();
var User = mongoose.model('User', schema);
var constants = require('../util/constants.js');




/**
 * validate a user existence in DB
 */
function isUserInDB(name, callback) {
	var query = { name : name};
	User.findOne(query, function(err, user) {
		
	    if (err) {
	    	//find user err
	    	callback(err,null)
	    }
	    else {
	    	if (user != null) {
	    		//already have this user name in database
	    		var err=constants.USER_CAN_NOT_REGISTER
				callback(err,user);
			}
	    	else {
	    		//user name do not exist in database
	    		callback(null,null)
	    	}
	    }
	    
	});
}

/**
 * create a new user in DB
 * @returns
 */
function createUser(aUser, callback) {
	
	// check the user id if it exists already, if exists, we should fail register
	isUserInDB(aUser.name, function(err,userExist) {
		
		if (userExist == null&&!err) {
			var user = new User(aUser);
			// insert a new user to db
			user.save(function (error, userObj) {
				if (err) {
					//fail to create a user
					callback(error, userObj)
				}
				else {
					//User is inserted successfully
					callback(null, userObj)
				}
				
			});
		}
		else { 
			//Failed to create a user since the user id exists in the system already.
			callback(err, aUser)
		}
		
	});
}





module.exports = {
		createUser : createUser
         
};

