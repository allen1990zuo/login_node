
//console server
var express = require('express');
var app = express();
var bodyParser= require('body-parser');
var mongoose= require('mongoose');
var morgan=require('morgan');
var config = require('./config/config.json');
var port = config.SERVER_PORT;
app.use(morgan('dev'));  // log every request to the console
app.use(bodyParser.json()); // get information from html forms
app.use(bodyParser.urlencoded({ extended: true}));
app.use(function(req, res, next) {
	 res.setHeader('Access-Control-Allow-Origin', '*');
	 res.setHeader('Access-Control-Allow-Credentials', 'true');
	 res.setHeader('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS,POST,PUT,DELETE');
	 res.setHeader('Access-Control-Allow-Headers', 'Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers');
	//and remove cacheing so we get the most recent comments
	 res.setHeader('Cache-Control', 'no-cache');
	 next();
	});
//initialize the DB connections
//load configuration details from the server configuration JSON
var dbURL = config.DB_URL;
mongoose.Promise= global.Promise;
mongoose.connect(dbURL);
	

//routes
require('./routes/userRoutes.js')(app);

// non SSL
var http = require('http').createServer(app);
http.listen(config.SERVER_PORT, function(){
	  console.log('server is listening on :' + config.SERVER_PORT);
	  
});	

